//
//  TileGridView.swift
//  Dynamic Grid View
//
//  Created by Patil, Ritesh on 4/29/20.
//  Copyright © 2020 Patil, Ritesh. All rights reserved.
//

import SwiftUI

public struct TileGridView {
    
    private let viewModel: ViewModel
    
    public init(viewModel: ViewModel) {
        
        self.viewModel = viewModel
        
    }
    
}
public extension TileGridView {
    
    /// View model for a Tile View
    struct ViewModel {
        
        public var tileViewChunk: [[Type]]
        
        public init( tileViewChunk: [[Type]]) {
            self.tileViewChunk =   tileViewChunk
            
        }
     }
    
}


extension TileGridView: View {
    
    public var body: some View {
            VStack( spacing: 16) {
                ForEach(0 ..< self.viewModel.tileViewChunk.count) {   i  in
                    
                    HStack( spacing: 16) {
                        
                        ForEach(0 ..< self.viewModel.tileViewChunk[i].count) {  j in
                            
                            TileView(data: self.viewModel.tileViewChunk[i][j])
                            
                        }
                        
                    }
                }
                
            }.padding(8)
//        }
        
    }
    
}



struct TileGridViewPreviews: PreviewProvider {
    
    static var previews: some View {
        
        let viewModel = TileGridView.ViewModel(
            tileViewChunk: []
        )
        
        return TileGridView(viewModel: viewModel)
        
    }
    
}




