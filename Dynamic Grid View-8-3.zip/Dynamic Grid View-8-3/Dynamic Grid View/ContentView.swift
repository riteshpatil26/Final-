//
//  ContentView.swift
//  Dynamic Grid View
//
//  Created by Patil, Ritesh on 4/21/20.
//  Copyright © 2020 Patil, Ritesh. All rights reserved.
//

import SwiftUI

struct ContentView: View {
 
    
    struct ViewModel {
        
        
       public var tileView: [Type]
        
        
        public init(tileView : [Type]) {
      
            self.tileView = tileView
            
        }
        
        func pageCount(cellCount: Int) -> Int {
            let quotient = tileView.count / cellCount
            let remainder = tileView.count % cellCount
            return remainder > 0 ? (quotient + 1 ) : quotient
        }

       
        
        func pageRows(_ index: Int, cellCount: Int , rowCount: Int , rowItemCount: Int) -> [[Type]] {
            if index < pageCount(cellCount: cellCount) {
                let startIndex =  index * (cellCount)
                var lastIndex = startIndex + cellCount - 1
                lastIndex = tileView.count > lastIndex ? lastIndex : (tileView.count - 1)
                let pageItems = Array<Type>(tileView[startIndex...lastIndex])
                var rows = [[Type]]()
                
                for i in 0..<rowCount {
                    let rowStart = i * rowItemCount
                    var rowEnd = rowStart + rowItemCount - 1
                    if rowStart < pageItems.count {
                        rowEnd = rowEnd < pageItems.count ? rowEnd : pageItems.count - 1
                        let row = Array<Type>(pageItems[rowStart...rowEnd])
                        rows.append(row)
                    }
                }
                return rows
            }
            return []
        }

    }
    
    
    let viewModel = ContentView.ViewModel(
    
        tileView: [

            Type(iconName: "Home", planName: "Theta Health Plan", planType: "Medical"),
           
            Type(iconName: "Filter", planName: "Dental Plan with MetLife", planType: "Dental"),
                       Type(iconName: "Search", planName: "Theta Vision", planType: "Vision"),
                       Type(iconName: "Chat", planName: "CVS Caremark", planType: "Prescriptions"),
                       Type(iconName: "Home", planName: "Theta Health Plan 1", planType: "Medical"),
                       Type(iconName: "Filter", planName: "Dental Plan with MetLife 1", planType: "Dental"),
                       Type(iconName: "Search", planName: "Theta Vision 1", planType: "Vision"),
                       Type(iconName: "Chat", planName: "CVS Caremark 1", planType: "Prescriptions"),
                       Type(iconName: "Home", planName: "Theta Health Plan 2", planType: "Medical"),
                       Type(iconName: "Filter", planName: "Dental Plan with MetLife 2", planType: "Dental"),
                       Type(iconName: "Search", planName: "Theta Vision 2", planType: "Vision"),
                       Type(iconName: "Chat", planName: "CVS Caremark 2", planType: "Prescriptions"),
//                       Type(iconName: "Chat", planName: "CVS Caremark 3", planType: "Prescriptions")

        ]
    )
    
 
    
    
    
    var body: some View {
        
        
        
        
          
            ScrollView(.horizontal, showsIndicators: true){
                
                HStack(spacing: 16) {
                    ForEach(0..<self.viewModel.pageCount(cellCount: 4),id:\.self){ pageIndex in
                        
                        TileGridView(viewModel: TileGridView.ViewModel.init(tileViewChunk: self.viewModel.pageRows(pageIndex, cellCount: 4, rowCount: 2, rowItemCount: 2)))
                        
                    }
                    
                    
                }
                .padding(.leading, 0)
            }.background(Color.yellow.opacity(0.8).edgesIgnoringSafeArea(.top))
            .edgesIgnoringSafeArea(.bottom)
            
//            SwiftyUIScrollView(axis: .horizontal, numberOfPages: self.viewModel.pageCount(), pagingEnabled: true, pageControlEnabled: true, hideScrollIndicators: true) {
//                HStack(spacing: 16) {
//                    ForEach(0..<self.viewModel.pageCount(),id:\.self){ pageIndex in
//
//                        TileGridView(viewModel: TileGridView.ViewModel.init(tileViewChunk: self.viewModel.pageRows(pageIndex, cellCount: 4, rowCount: 2, rowItemCount: 2)))
//
//                    }
//
//
//                }
//                .padding(.leading, 0)
//            }
      
    }
 
}
extension Array {
    func generateGrid(into size: Int) -> [[Element]] {
        return stride(from: 0, to: count, by: size).map {
            Array(self[$0 ..< Swift.min($0 + size, count)])
        }
    }
    
//   func pageCount(cellCount: Int = 4) -> Int {
//    let quotient = self.count / cellCount
//       let remainder = self.count % cellCount
//       return remainder > 0 ? (quotient + 1 ) : quotient
//   }
//
//   func pageElement(index :Int,cellCount :Int = 4) -> [Element] {
//
//       if index < pageCount(cellCount: cellCount){
//           let startIndex =  index * (cellCount)
//             var lastIndex = startIndex + cellCount - 1
//        lastIndex = self.count > lastIndex ? lastIndex : (self.count - 1)
//        return Array(self[startIndex...lastIndex])
//       }
//       return[]
//   }
    
    
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

public struct TileView :View {
   var data :Type
//   var data1 :Type
    public var body: some View {
        
            VStack(alignment: .leading,spacing: 0) {
                HStack {
                    Spacer()
                    Image("Home").resizable().frame(width: 28, height: 28).aspectRatio(contentMode: .fit)
                }
                Spacer()
                HStack {
                    Text(data.planName).lineLimit(2)
                }
                Spacer()
                HStack {
                    Text(data.planType)
                }.padding([.bottom], 4)
                }

        .padding(8)
        .background(Color.red.opacity(0.4))
        .cornerRadius(14)
            .lineLimit(1).frame(height: 138.0)
    }
}

public struct Type{
    public var iconName: String
    public var planName: String
    public var planType: String
    private let uuid = UUID()
    
    public init(iconName: String, planName: String, planType: String) {
        self.iconName = iconName
        self.planName = planName
        self.planType = planType
    }
    
}

