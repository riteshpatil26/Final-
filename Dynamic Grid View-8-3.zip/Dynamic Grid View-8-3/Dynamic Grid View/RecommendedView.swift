//
//  RecommendedView.swift
//  Dynamic Grid View
//
//  Created by Patil, Ritesh on 4/29/20.
//  Copyright © 2020 Patil, Ritesh. All rights reserved.
//

import SwiftUI

public struct RecommendedView: View {
    @State var data = [Type(iconName: "Home", planName: "Theta Health Plan", planType: "Medical"),
                          Type(iconName: "Filter", planName: "Dental Plan with MetLife", planType: "Dental"),
                          Type(iconName: "Search", planName: "Theta Vision", planType: "Vision"),
                          Type(iconName: "Chat", planName: "CVS Caremark", planType: "Prescriptions")
                   
       ]
    
   
    
        public var body :some View{
           
            VStack(alignment: .leading, spacing: 8.0){
                Text("Recommended Plans").padding(.leading, 8.0)
                ScrollView(.horizontal, content: {
                               HStack(spacing: 8) {
                                ForEach(1...3,id:\.self){
                                       i in
                                        
                                    TileView(data:self.data[i])
                                       
                                   }
                               }
                               .padding()
                                
                           })
                               .frame(height: 150)
            }
            
           
        }
    
    
    
}

struct RecommendedView_Previews: PreviewProvider {
    static var previews: some View {
        RecommendedView()
    }
}



